#include "Character.h"
#include "Tile.h"

string Character::getTyp() const
{
    return typ;
}

void Character::setTile(Tile *newTile)
{
    tile = newTile;
}

Tile *Character::getTile() const
{
    return tile;
}

Character::Character(const std::string &typ) : typ(typ), tile(nullptr)
{}
