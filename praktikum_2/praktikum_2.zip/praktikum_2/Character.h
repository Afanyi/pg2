#ifndef CHARACTER_H
#define CHARACTER_H
#include <string>
using std::string;
class Tile;
class Character{
    string typ;
    Tile* tile;
public:
    Character(const string &typ);
    string getTyp() const;
    void setTile(Tile *newTile);
    friend void move();
    Tile *getTile() const;
};

#endif // CHARACTER_H
